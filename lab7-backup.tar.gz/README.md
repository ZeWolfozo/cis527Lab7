# WordPress Docker Backup Restoration Guide

## Prerequisites
- Ubuntu 24.04 server configured per Lab 5
- Docker and Docker Compose installed
- Apache with reverse proxy configured

## File Contents
This backup contains:
- `docker-compose.yml` - Docker Compose configuration
- `wordpress_backup.sql` - Complete MySQL database dump
- `wp-content/` - WordPress themes, plugins, and uploads
- `*.conf` - Apache reverse proxy configuration
- `README.md` - This file

## Restoration Steps

### 1. Prepare the Environment
```bash
sudo mkdir -p /opt/wordpress
cd /opt/wordpress
```

### 2. Extract and Copy Files
```bash
# Extract the backup archive
tar -xzf lab7-backup.tar.gz

# Copy docker-compose.yml
cp lab7-backup/docker-compose.yml /opt/wordpress/
```

### 3. Start Docker Containers
```bash
cd /opt/wordpress
docker compose up -d
```

Wait 30-60 seconds for containers to fully initialize.

### 4. Verify Containers are Running
```bash
docker ps
```
You should see two containers: `wordpress-db-1` and `wordpress-wordpress-1`

### 5. Restore MySQL Database
```bash
docker exec -i wordpress-db-1 mysql -u root -psomewordpress wordpress < lab7-backup/wordpress_backup.sql
```

### 6. Restore wp-content Directory
```bash
docker cp lab7-backup/wp-content/. wordpress-wordpress-1:/var/www/html/wp-content/
```

### 7. Fix File Permissions
```bash
docker exec wordpress-wordpress-1 chown -R www-data:www-data /var/www/html/wp-content
```

### 8. Restore Apache Reverse Proxy Configuration
```bash
# Copy configuration file
sudo cp lab7-backup/*.conf /etc/apache2/sites-available/

# Enable the site (adjust filename as needed)
sudo a2ensite wordpress.conf

# Enable required Apache modules if not already enabled
sudo a2enmod proxy
sudo a2enmod proxy_http

# Test configuration
sudo apache2ctl configtest

# Restart Apache
sudo systemctl restart apache2
```

### 9. Verify WordPress is Accessible
Visit your WordPress site at the configured domain to confirm restoration was successful.

## Database Credentials
From docker-compose.yml:
- **MySQL Root Password**: somewordpress
- **Database Name**: wordpress
- **Database User**: wordpress
- **Database User Password**: wordpress
- **Database Host**: db:3306 (internal Docker network)

## Docker Configuration Notes
- WordPress runs on port 8080 internally, mapped from container port 80
- MySQL database uses isolated internal network (db_network)
- WordPress container connects to both internal database network and external frontend network
- Data persists in Docker volumes: `db_data` and `wp_data`
